import { ShapeType } from './types';

export const GRID_ROWS = 8;
export const GRID_COLS = 8;
export const CELL_SIZE = 50; // pixels

export const SHAPE_COLORS: Record<ShapeType, string> = {
  [ShapeType.CIRCLE]: '#EF4444', // red-500
  [ShapeType.SQUARE]: '#3B82F6', // blue-500
  [ShapeType.TRIANGLE]: '#22C55E', // green-500
  [ShapeType.DIAMOND]: '#EAB308', // yellow-500
  [ShapeType.HEXAGON]: '#A855F7', // purple-500
  [ShapeType.STAR]: '#F97316', // orange-500
};

export const ALL_SHAPE_TYPES: ShapeType[] = [
  ShapeType.CIRCLE,
  ShapeType.SQUARE,
  ShapeType.TRIANGLE,
  ShapeType.DIAMOND,
  ShapeType.HEXAGON,
  ShapeType.STAR,
];

export const MATCH_THRESHOLD = 3;
export const POINTS_PER_ITEM = 10;

// Animation Constants
export const ATTEMPTING_SWAP_ANIMATION_DURATION = 150; // ms for animating items to swapped positions
export const SPECIAL_ACTIVATION_ANIMATION_DURATION = 200; // ms for quick special effect visuals
export const MATCH_ANIMATION_DURATION = 250; // ms
export const INVALID_SWAP_ANIMATION_DURATION = 150; // ms for animating items back on invalid swap
export const FALL_ANIMATION_SPEED = 7; // pixels per frame; adjust for desired speed (was 8)
export const REFILL_ANIMATION_SPEED = 7; // pixels per frame (was 8)
export const DRAG_ITEM_SCALE = 1.1; // Scale factor for item being dragged
export const DRAG_ITEM_ALPHA = 0.75; // Alpha for item being dragged

// Special Item Constants
export const BOMB_EFFECT_RADIUS = 1; // For 3x3 explosion (1 means 1 item out from center)

// Hint and Shuffle Constants
export const HINT_DELAY = 3000; // ms (3 seconds)
export const HINT_PULSE_SPEED = 300; // ms per pulse cycle for hint visualization
export const NO_MOVES_MESSAGE_DURATION = 2000; // ms (message shown before shuffle)
export const SHUFFLE_DELAY = 1000; // ms (delay after message before shuffle action)