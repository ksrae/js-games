
import React, { useRef, useEffect, useCallback, useState } from 'react';
import { ShapeType, GridItem, Position, SpecialItemType } from '../types';
import { 
  GRID_ROWS, 
  GRID_COLS, 
  CELL_SIZE, 
  SHAPE_COLORS, 
  ALL_SHAPE_TYPES,
  POINTS_PER_ITEM,
  ATTEMPTING_SWAP_ANIMATION_DURATION,
  SPECIAL_ACTIVATION_ANIMATION_DURATION,
  MATCH_ANIMATION_DURATION,
  INVALID_SWAP_ANIMATION_DURATION,
  FALL_ANIMATION_SPEED,
  REFILL_ANIMATION_SPEED,
  DRAG_ITEM_SCALE,
  DRAG_ITEM_ALPHA,
  BOMB_EFFECT_RADIUS,
  HINT_DELAY,
  HINT_PULSE_SPEED,
  SHUFFLE_DELAY,
  NO_MOVES_MESSAGE_DURATION
} from '../constants';

interface GameCanvasProps {
  width: number;
  height: number;
  onScoreUpdate: (score: number) => void;
  onGameOver: () => void;
  onShuffleBoardStateChange: (isShuffling: boolean) => void;
}

interface AnimatedItem { // For falling/refilling
  item: GridItem;
  fromY: number;
  currentY: number;
  toY: number;
  col: number;
  landed?: boolean;
}

interface AnimatedSwapItem { // For invalid swap animation (after attempting_swap fails)
  item: GridItem;
  startX: number; 
  startY: number;
  currentX: number;
  currentY: number;
  endX: number;
  endY: number;
  originalGridPos: Position; 
}

interface AttemptingSwapDetail {
  item1: GridItem; // Item originally at pos1Start
  item2: GridItem; // Item originally at pos2Start
  pos1Start: Position; 
  pos2Start: Position;
  // Visual animation targets (item1 goes to pos2Start's coords, item2 to pos1Start's coords)
  item1TargetX: number; item1TargetY: number;
  item2TargetX: number; item2TargetY: number;
  // Current animated positions
  item1CurrentX: number; item1CurrentY: number;
  item2CurrentX: number; item2CurrentY: number;
  isDragSwap: boolean;
  draggedItemOriginalId: string; // ID of the item initially picked up by the player
}


interface SpecialActivationDetail {
  pos: Position;
  type: SpecialItemType;
  effectCells: Position[]; 
  originalItem: GridItem; 
}

interface AnimationState {
  type: 'idle' | 'attempting_swap' | 'special_activating' | 'matching' | 'falling' | 'refilling' | 'invalid_swap';
  startTime?: number;
  items?: Position[] | AnimatedItem[]; 
  activationDetails?: SpecialActivationDetail[]; 
  processedActivations?: Set<string>; 
  allCellsToClearAfterSpecialActivation?: Set<string>;
  animatedSwapItems?: AnimatedSwapItem[]; 
  attemptingSwapDetail?: AttemptingSwapDetail;
}

interface AnalysisResult {
  positionsToClear: Set<string>; 
  specialsToCreate: { pos: Position; type: SpecialItemType; originalItem: GridItem }[];
  specialsToActivate: SpecialActivationDetail[]; 
}

const posToString = (p: Position) => `${p.row}-${p.col}`;
const stringToPos = (s: string): Position => ({ row: parseInt(s.split('-')[0]), col: parseInt(s.split('-')[1])});

type Hint = Position | Position[];


const GameCanvas: React.FC<GameCanvasProps> = ({ width, height, onScoreUpdate, onGameOver, onShuffleBoardStateChange }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  
  const gridRef = useRef<(GridItem | null)[][]>([]);
  const scoreRef = useRef<number>(0);

  const isDraggingRef = useRef<boolean>(false);
  const startDragCellRef = useRef<Position | null>(null); // Cell where drag initiated
  const draggedItemMousePosRef = useRef<{ x: number; y: number } | null>(null);
  const potentialClickRef = useRef<boolean>(false);
  const clickStartPosRef = useRef<Position | null>(null); 
  const lastFailedSwapTargetRef = useRef<Position | null>(null);
  
  const isProcessingMoveRef = useRef<boolean>(false); 
  const animationStateRef = useRef<AnimationState>({ type: 'idle' });
  
  const animationFrameIdRef = useRef<number | null>(null);

  const hintTimerIdRef = useRef<number | null>(null);
  const hintToDisplayRef = useRef<Hint | null>(null);
  const lastInteractionTimeRef = useRef<number>(Date.now());

  const hasShuffledRecentlyRef = useRef<boolean>(false);
  const isShufflingBoardRef = useRef<boolean>(false);


  const createRandomItem = useCallback((excludeTypes: ShapeType[] = []): GridItem => {
    let availableTypes = ALL_SHAPE_TYPES.filter(t => !excludeTypes.includes(t));
    if (availableTypes.length === 0) availableTypes = ALL_SHAPE_TYPES;
    
    const type = availableTypes[Math.floor(Math.random() * availableTypes.length)];
    return { type, color: SHAPE_COLORS[type], id: Math.random().toString(36).substring(7) };
  }, []);

  const drawShape = useCallback((
    ctx: CanvasRenderingContext2D, 
    item: GridItem, 
    x: number, y: number, 
    size: number, 
    alpha = 1, 
    scale = 1
  ) => {
    ctx.save();
    ctx.globalAlpha = alpha;
    
    const actualSize = size * scale;
    const offset = (size - actualSize) / 2;
    const finalX = x + offset;
    const finalY = y + offset;

    ctx.fillStyle = item.color;
    const s = actualSize * 0.8; 
    const p = (actualSize - s) / 2; 
    const cx = finalX + actualSize / 2;
    const cy = finalY + actualSize / 2;

    if (item.special !== undefined) { 
        ctx.strokeStyle = item.color; 
        ctx.fillStyle = item.color;
        ctx.lineWidth = Math.max(2, actualSize * 0.08); 
        const specialPadding = actualSize * 0.20; 
        
        const currentSpecial: SpecialItemType = item.special; 
        switch (currentSpecial) { 
            case SpecialItemType.LINE_H: {
                const VSpacing = actualSize * 0.2;
                ctx.beginPath();
                ctx.moveTo(finalX + specialPadding, cy - VSpacing); ctx.lineTo(finalX + actualSize - specialPadding, cy - VSpacing);
                ctx.moveTo(finalX + specialPadding, cy); ctx.lineTo(finalX + actualSize - specialPadding, cy);
                ctx.moveTo(finalX + specialPadding, cy + VSpacing); ctx.lineTo(finalX + actualSize - specialPadding, cy + VSpacing);
                ctx.stroke();
                break;
            }
            case SpecialItemType.LINE_V: {
                const HSpacing = actualSize * 0.2;
                ctx.beginPath();
                ctx.moveTo(cx - HSpacing, finalY + specialPadding); ctx.lineTo(cx - HSpacing, finalY + actualSize - specialPadding);
                ctx.moveTo(cx, finalY + specialPadding); ctx.lineTo(cx, finalY + actualSize - specialPadding);
                ctx.moveTo(cx + HSpacing, finalY + specialPadding); ctx.lineTo(cx + HSpacing, finalY + actualSize - specialPadding);
                ctx.stroke();
                break;
            }
            case SpecialItemType.BOMB: {
                ctx.fillStyle = '#4A5568'; 
                ctx.beginPath(); ctx.arc(cx, cy, s / 2 * 0.85, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#A0AEC0'; 
                ctx.fillRect(cx - s * 0.1, cy - s / 2 * 0.85 - s * 0.1, s * 0.2, s * 0.15);
                ctx.fillStyle = item.color; 
                ctx.beginPath(); ctx.arc(cx, cy - s / 2 * 0.85 - s * 0.1 - s*0.05, s * 0.08, 0, Math.PI * 2); ctx.fill();
                break;
            }
            case SpecialItemType.SCREEN_CLEAR: {
                const outerR = s * 0.45;
                const innerR = s * 0.2;
                for (let i = 0; i < 6; i++) {
                    ctx.fillStyle = SHAPE_COLORS[ALL_SHAPE_TYPES[i % ALL_SHAPE_TYPES.length]];
                    ctx.beginPath();
                    ctx.moveTo(cx, cy);
                    ctx.arc(cx, cy, outerR, (i * Math.PI * 2) / 6, ((i + 1) * Math.PI * 2) / 6);
                    ctx.closePath();
                    ctx.fill();
                }
                ctx.fillStyle = 'white';
                ctx.beginPath(); ctx.arc(cx, cy, innerR, 0, Math.PI * 2); ctx.fill();
                break;
            }
            case SpecialItemType.CROSS_CLEAR: {
                ctx.fillStyle = item.color;
                const barWidth = actualSize * 0.25;
                const barLength = actualSize * 0.7;
                const barOffset = (actualSize - barLength)/2;
                ctx.fillRect(finalX + barOffset, cy - barWidth/2, barLength, barWidth);
                ctx.fillRect(cx - barWidth/2, finalY + barOffset, barWidth, barLength);
                break;
            }
        }
    } else { // Standard shapes
        switch (item.type) {
        case ShapeType.CIRCLE: ctx.beginPath(); ctx.arc(cx, cy, s / 2, 0, 2 * Math.PI); ctx.fill(); break;
        case ShapeType.SQUARE: ctx.fillRect(finalX + p, finalY + p, s, s); break;
        case ShapeType.TRIANGLE: ctx.beginPath(); ctx.moveTo(cx, finalY + p); ctx.lineTo(finalX + p, finalY + p + s); ctx.lineTo(finalX + p + s, finalY + p + s); ctx.closePath(); ctx.fill(); break;
        case ShapeType.DIAMOND: ctx.beginPath(); ctx.moveTo(cx, finalY + p); ctx.lineTo(finalX + p + s, cy); ctx.lineTo(cx, finalY + p + s); ctx.lineTo(finalX + p, cy); ctx.closePath(); ctx.fill(); break;
        case ShapeType.HEXAGON: const hr = s / 2; ctx.beginPath(); for (let i = 0; i < 6; i++) ctx.lineTo(cx + hr * Math.cos(Math.PI/3*i), cy + hr * Math.sin(Math.PI/3*i)); ctx.closePath(); ctx.fill(); break;
        case ShapeType.STAR: const sp=5, oR=s/2, iR=s/4; let rot=Math.PI/2*3, step=Math.PI/sp; ctx.beginPath(); ctx.moveTo(cx,cy-oR); for (let i=0;i<sp;i++){ctx.lineTo(cx+Math.cos(rot)*oR,cy+Math.sin(rot)*oR); rot+=step; ctx.lineTo(cx+Math.cos(rot)*iR,cy+Math.sin(rot)*iR); rot+=step;} ctx.lineTo(cx,cy-oR); ctx.closePath(); ctx.fill(); break;
        }
    }
    ctx.restore();
  }, []);

  const getSpecialEffectCells = useCallback((itemPos: Position, specialType: SpecialItemType): Position[] => {
    const effectCells: Position[] = [];
    switch (specialType) {
        case SpecialItemType.LINE_H:
            for (let c = 0; c < GRID_COLS; c++) effectCells.push({ row: itemPos.row, col: c });
            break;
        case SpecialItemType.LINE_V:
            for (let r = 0; r < GRID_ROWS; r++) effectCells.push({ row: r, col: itemPos.col });
            break;
        case SpecialItemType.BOMB:
            for (let rO = -BOMB_EFFECT_RADIUS; rO <= BOMB_EFFECT_RADIUS; rO++) {
                for (let cO = -BOMB_EFFECT_RADIUS; cO <= BOMB_EFFECT_RADIUS; cO++) {
                    const R = itemPos.row + rO; const C = itemPos.col + cO;
                    if (R >= 0 && R < GRID_ROWS && C >= 0 && C < GRID_COLS) effectCells.push({ row: R, col: C });
                }
            }
            break;
        case SpecialItemType.SCREEN_CLEAR:
            for (let r = 0; r < GRID_ROWS; r++) for (let c = 0; c < GRID_COLS; c++) if(gridRef.current[r]?.[c]) effectCells.push({ row: r, col: c });
            break;
        case SpecialItemType.CROSS_CLEAR:
            for (let c = 0; c < GRID_COLS; c++) if (!effectCells.some(p => p.row === itemPos.row && p.col === c)) effectCells.push({ row: itemPos.row, col: c });
            for (let r = 0; r < GRID_ROWS; r++) if (!effectCells.some(p => p.row === r && p.col === itemPos.col)) effectCells.push({ row: r, col: itemPos.col });
            break;
    }
    return effectCells;
  }, []);

  const analyzeGridState = useCallback((currentGrid: (GridItem | null)[][]): AnalysisResult => {
    const result: AnalysisResult = {
        positionsToClear: new Set<string>(),
        specialsToCreate: [],
        specialsToActivate: [],
    };
    const processedCells = new Set<string>(); 

    const addMatchToProcessed = (matchPositions: Position[], specialCreatedAtIndex: number = -1) => {
        matchPositions.forEach((p, index) => {
            processedCells.add(posToString(p));
            if (index !== specialCreatedAtIndex) { 
                 result.positionsToClear.add(posToString(p));
            }
        });
    };
    
    // 5-in-a-line (SCREEN_CLEAR) - Horizontal
    for (let r = 0; r < GRID_ROWS; r++) {
        for (let c = 0; c < GRID_COLS - 4; c++) {
            if (processedCells.has(posToString({row: r, col: c}))) continue;
            const item = currentGrid[r][c];
            if (!item) continue;
            const matchPositions: Position[] = [{row: r, col: c}];
            for (let k = 1; k < 5; k++) {
                if (c + k < GRID_COLS && currentGrid[r][c+k]?.type === item.type) matchPositions.push({row:r, col:c+k}); else break;
            }
            if (matchPositions.length === 5 && matchPositions.every(p => !processedCells.has(posToString(p)))) {
                const specialIndex = 2; 
                result.specialsToCreate.push({ pos: matchPositions[specialIndex], type: SpecialItemType.SCREEN_CLEAR, originalItem: { ...currentGrid[matchPositions[specialIndex].row][matchPositions[specialIndex].col]! } });
                addMatchToProcessed(matchPositions, specialIndex);
            }
        }
    }
    // 5-in-a-line (SCREEN_CLEAR) - Vertical
    for (let c = 0; c < GRID_COLS; c++) {
        for (let r = 0; r < GRID_ROWS - 4; r++) {
           if (processedCells.has(posToString({row: r, col: c}))) continue;
            const item = currentGrid[r][c];
            if (!item) continue;
            const matchPositions: Position[] = [{row: r, col: c}];
            for (let k = 1; k < 5; k++) {
                if (r + k < GRID_ROWS && currentGrid[r+k]?.[c]?.type === item.type) matchPositions.push({row:r+k, col:c}); else break;
            }
            if (matchPositions.length === 5 && matchPositions.every(p => !processedCells.has(posToString(p)))) {
                const specialIndex = 2;
                result.specialsToCreate.push({ pos: matchPositions[specialIndex], type: SpecialItemType.SCREEN_CLEAR, originalItem: { ...currentGrid[matchPositions[specialIndex].row][matchPositions[specialIndex].col]! } });
                addMatchToProcessed(matchPositions, specialIndex);
            }
        }
    }

    // L/T-shape 5-item matches (CROSS_CLEAR)
    for (let r = 0; r < GRID_ROWS; r++) {
        for (let c = 0; c < GRID_COLS; c++) {
            if (processedCells.has(posToString({row:r, col:c}))) continue;
            const centerItem = currentGrid[r][c];
            if (!centerItem) continue;

            const hLine3 = [{row:r, col:c-1}, {row:r, col:c}, {row:r, col:c+1}].filter(p=> p.col >=0 && p.col < GRID_COLS && currentGrid[p.row]?.[p.col]?.type === centerItem.type);
            const vLine3 = [{row:r-1, col:c}, {row:r, col:c}, {row:r+1, col:c}].filter(p=> p.row >=0 && p.row < GRID_ROWS && currentGrid[p.row]?.[p.col]?.type === centerItem.type);

            if (hLine3.length === 3 && vLine3.length === 3) { // T or + shape
                const matchPositions = [...new Set([...hLine3, ...vLine3].map(posToString))].map(stringToPos);
                if (matchPositions.length === 5 && matchPositions.every(p => !processedCells.has(posToString(p)) && currentGrid[p.row]?.[p.col]?.type === centerItem.type)) {
                    result.specialsToCreate.push({ pos: {row:r, col:c}, type: SpecialItemType.CROSS_CLEAR, originalItem: {...centerItem}});
                    addMatchToProcessed(matchPositions, matchPositions.findIndex(p => p.row ===r && p.col === c));
                    continue; 
                }
            }
            
             const LPatterns = [
                [[{row:r,col:c}, {row:r+1,col:c}, {row:r+2,col:c}], [{row:r,col:c}, {row:r,col:c+1}, {row:r,col:c+2}]], 
                [[{row:r,col:c}, {row:r+1,col:c}, {row:r+2,col:c}], [{row:r,col:c}, {row:r,col:c-1}, {row:r,col:c-2}]], 
                [[{row:r,col:c}, {row:r-1,col:c}, {row:r-2,col:c}], [{row:r,col:c}, {row:r,col:c+1}, {row:r,col:c+2}]], 
                [[{row:r,col:c}, {row:r-1,col:c}, {row:r-2,col:c}], [{row:r,col:c}, {row:r,col:c-1}, {row:r,col:c-2}]], 
             ];

            for (const pattern of LPatterns) {
                const line1Positions = pattern[0].filter(p => p.row >= 0 && p.row < GRID_ROWS && p.col >= 0 && p.col < GRID_COLS && currentGrid[p.row]?.[p.col]?.type === centerItem.type);
                const line2Positions = pattern[1].filter(p => p.row >= 0 && p.row < GRID_ROWS && p.col >= 0 && p.col < GRID_COLS && currentGrid[p.row]?.[p.col]?.type === centerItem.type);

                if (line1Positions.length === 3 && line2Positions.length === 3) {
                    const combined = [...new Set([...line1Positions, ...line2Positions].map(posToString))].map(stringToPos);
                    if (combined.length === 5 && combined.every(p => !processedCells.has(posToString(p)))) {
                         result.specialsToCreate.push({ pos: {row:r, col:c}, type: SpecialItemType.CROSS_CLEAR, originalItem: {...centerItem} });
                         addMatchToProcessed(combined, combined.findIndex(p => p.row === r && p.col === c));
                         break; 
                    }
                }
            }
        }
    }
    
    // 2x2 Square (BOMB)
    for (let r = 0; r < GRID_ROWS - 1; r++) {
        for (let c = 0; c < GRID_COLS - 1; c++) {
            const item = currentGrid[r][c];
            if (!item || processedCells.has(posToString({row:r, col:c}))) continue;
            const matchPositions: Position[] = [{row:r,col:c}, {row:r,col:c+1}, {row:r+1,col:c}, {row:r+1,col:c+1}];
            if (matchPositions.every(p => currentGrid[p.row][p.col]?.type === item.type && !processedCells.has(posToString(p)))) {
                result.specialsToCreate.push({ pos: {row:r, col:c}, type: SpecialItemType.BOMB, originalItem: { ...item } });
                addMatchToProcessed(matchPositions, 0); 
            }
        }
    }
    
    // 4-in-a-row (LINE_H/LINE_V) - Horizontal
    for (let r = 0; r < GRID_ROWS; r++) {
        for (let c = 0; c < GRID_COLS - 3; c++) {
            if (processedCells.has(posToString({row:r, col:c}))) continue;
            const item = currentGrid[r][c];
            if (!item) continue;
            const matchPositions: Position[] = [{row:r, col:c}];
            for (let k=1; k<4; k++) if(c+k < GRID_COLS && currentGrid[r][c+k]?.type === item.type) matchPositions.push({row:r, col:c+k}); else break;
            
            if (matchPositions.length === 4 && matchPositions.every(p => !processedCells.has(posToString(p)))) {
                const specialIndex = matchPositions.findIndex(p => !currentGrid[p.row][p.col]?.special);
                const actualSpecialIndex = specialIndex !== -1 ? specialIndex : 0; 
                result.specialsToCreate.push({ pos: matchPositions[actualSpecialIndex], type: SpecialItemType.LINE_H, originalItem: { ...currentGrid[matchPositions[actualSpecialIndex].row][matchPositions[actualSpecialIndex].col]! }});
                addMatchToProcessed(matchPositions, actualSpecialIndex);
            }
        }
    }
    // 4-in-a-row (LINE_H/LINE_V) - Vertical
     for (let c = 0; c < GRID_COLS; c++) {
        for (let r = 0; r < GRID_ROWS - 3; r++) {
            if (processedCells.has(posToString({row:r, col:c}))) continue;
            const item = currentGrid[r][c];
            if (!item) continue;
            const matchPositions: Position[] = [{row:r, col:c}];
            for (let k=1; k<4; k++) if(r+k < GRID_ROWS && currentGrid[r+k]?.[c]?.type === item.type) matchPositions.push({row:r+k, col:c}); else break;

            if (matchPositions.length === 4 && matchPositions.every(p => !processedCells.has(posToString(p)))) {
                 const specialIndex = matchPositions.findIndex(p => !currentGrid[p.row][p.col]?.special);
                 const actualSpecialIndex = specialIndex !== -1 ? specialIndex : 0;
                 result.specialsToCreate.push({ pos: matchPositions[actualSpecialIndex], type: SpecialItemType.LINE_V, originalItem: { ...currentGrid[matchPositions[actualSpecialIndex].row][matchPositions[actualSpecialIndex].col]! }});
                 addMatchToProcessed(matchPositions, actualSpecialIndex);
            }
        }
    }

    // 3-in-a-row (Normal match) - Horizontal
    for (let r = 0; r < GRID_ROWS; r++) {
        for (let c = 0; c < GRID_COLS - 2; c++) {
            if (processedCells.has(posToString({row:r, col:c}))) continue;
            const item = currentGrid[r][c];
            if (!item) continue;
            const matchPositions: Position[] = [{row:r,col:c}];
            for(let k=1; k<3; k++) if(c+k < GRID_COLS && currentGrid[r][c+k]?.type === item.type) matchPositions.push({row:r,col:c+k}); else break;
            if (matchPositions.length === 3 && matchPositions.every(p => !processedCells.has(posToString(p)))) {
                 addMatchToProcessed(matchPositions); 
            }
        }
    }
    // 3-in-a-row (Normal match) - Vertical
    for (let c = 0; c < GRID_COLS; c++) {
        for (let r = 0; r < GRID_ROWS - 2; r++) {
           if (processedCells.has(posToString({row:r, col:c}))) continue;
            const item = currentGrid[r][c];
            if (!item) continue;
            const matchPositions: Position[] = [{row:r,col:c}];
            for(let k=1; k<3; k++) if(r+k < GRID_ROWS && currentGrid[r+k]?.[c]?.type === item.type) matchPositions.push({row:r+k,col:c}); else break;
             if (matchPositions.length === 3 && matchPositions.every(p => !processedCells.has(posToString(p)))) {
                addMatchToProcessed(matchPositions); 
            }
        }
    }
    
    result.positionsToClear.forEach(posStr => {
        const pos = stringToPos(posStr);
        const item = currentGrid[pos.row]?.[pos.col];
        if (item?.special !== undefined && 
            !result.specialsToCreate.some(spc => spc.pos.row === pos.row && spc.pos.col === pos.col) && 
            !result.specialsToActivate.some(sa => sa.pos.row === pos.row && sa.pos.col === pos.col)) { 
            const effectCells = getSpecialEffectCells(pos, item.special);
            result.specialsToActivate.push({ pos, type: item.special, effectCells, originalItem: {...item} });
        }
    });
    return result;
  }, [getSpecialEffectCells]);

  const removeMatchedItemsFromGrid = useCallback((matchedPositions: Position[]) => {
    if (matchedPositions.length === 0) return;
    matchedPositions.forEach(pos => {
      if (gridRef.current[pos.row]) gridRef.current[pos.row][pos.col] = null;
    });
  }, []);

  const applyGravityToGrid = useCallback(() => {
    let itemsFell = false;
    const newFallingItems: AnimatedItem[] = [];
    for (let c = 0; c < GRID_COLS; c++) {
      let emptyRow = -1;
      for (let r = GRID_ROWS - 1; r >= 0; r--) {
        if (gridRef.current[r][c] === null && emptyRow === -1) emptyRow = r;
        else if (gridRef.current[r][c] !== null && emptyRow !== -1) {
          const itemToMove = gridRef.current[r][c]!;
          newFallingItems.push({ item: itemToMove, fromY: r * CELL_SIZE, currentY: r * CELL_SIZE, toY: emptyRow * CELL_SIZE, col: c });
          gridRef.current[emptyRow][c] = itemToMove; gridRef.current[r][c] = null; emptyRow--; itemsFell = true;
        }
      }
    }
    return { itemsFell, newFallingItems };
  }, []);

  const refillGridWithNewItems = useCallback(() => {
    const newRefillingItems: AnimatedItem[] = [];
    let itemsAdded = false;
    for (let c = 0; c < GRID_COLS; c++) {
      let countNew = 0;
      for (let r = GRID_ROWS - 1; r >= 0; r--) {
        if (gridRef.current[r][c] === null) {
          countNew++; const newItem = createRandomItem(); gridRef.current[r][c] = newItem;
          newRefillingItems.push({ item: newItem, fromY: (r - countNew) * CELL_SIZE - (countNew * CELL_SIZE / 4), currentY: (r - countNew) * CELL_SIZE - (countNew * CELL_SIZE / 4), toY: r * CELL_SIZE, col: c });
          itemsAdded = true;
        }
      }
    }
    return { itemsAdded, newRefillingItems };
  }, [createRandomItem]);
  
  const findHint = useCallback((): Hint | null => {
    for (let r = 0; r < GRID_ROWS; r++) for (let c = 0; c < GRID_COLS; c++) if (gridRef.current[r][c]?.special !== undefined) return { row: r, col: c };
    for (let r = 0; r < GRID_ROWS; r++) {
        for (let c = 0; c < GRID_COLS; c++) {
            const item1 = gridRef.current[r][c]; if (!item1) continue;
            const neighbors: Position[] = [];
            if (c < GRID_COLS - 1) neighbors.push({row: r, col: c + 1}); 
            if (r < GRID_ROWS - 1) neighbors.push({row: r + 1, col: c}); 
            for (const nPos of neighbors) {
                const item2 = gridRef.current[nPos.row][nPos.col]; if (!item2) continue;
                const tempGrid = JSON.parse(JSON.stringify(gridRef.current)) as (GridItem | null)[][];
                [tempGrid[r][c], tempGrid[nPos.row][nPos.col]] = [tempGrid[nPos.row][nPos.col], tempGrid[r][c]];
                const analysis = analyzeGridState(tempGrid);
                if (analysis.positionsToClear.size > 0 || analysis.specialsToCreate.length > 0 || analysis.specialsToActivate.length > 0) return [{row: r, col: c}, nPos];
            }
        }
    }
    return null;
  }, [analyzeGridState]);

  const checkPossibleMoves = useCallback(() => !!findHint(), [findHint]);

  let shuffleBoard: () => void; 

  const processGameActions = useCallback((analysisResult: AnalysisResult, triggeredByClickPos?: Position) => {
    let anActionLedToAnimationOrGridChange = false;
    const { specialsToCreate } = analysisResult;
    let finalPositionsToClear = new Set<string>(analysisResult.positionsToClear);
    let allActivatedSpecials: SpecialActivationDetail[] = [...analysisResult.specialsToActivate];

    specialsToCreate.forEach(sp => {
        const itemAtPos = gridRef.current[sp.pos.row]?.[sp.pos.col];
        if (itemAtPos) { 
            gridRef.current[sp.pos.row][sp.pos.col] = {
                ...sp.originalItem, 
                id: itemAtPos.id, 
                special: sp.type,
            };
            finalPositionsToClear.delete(posToString(sp.pos)); 
            anActionLedToAnimationOrGridChange = true;
        }
    });
    
    const alreadyActivatedThisTurn = new Set<string>(); 
    if(triggeredByClickPos) { 
      const clickedItem = gridRef.current[triggeredByClickPos.row][triggeredByClickPos.col];
      if(clickedItem?.special !== undefined && !allActivatedSpecials.find(sa => sa.pos.row === triggeredByClickPos.row && sa.pos.col === triggeredByClickPos.col)) {
         const effectCells = getSpecialEffectCells(triggeredByClickPos, clickedItem.special);
         allActivatedSpecials.unshift({pos: triggeredByClickPos, type: clickedItem.special, effectCells, originalItem: {...clickedItem}});
      }
    }

    let currentActivations = [...allActivatedSpecials];
    let cascadeIterations = 0;
    const MAX_CASCADE_ITERATIONS = GRID_ROWS * GRID_COLS; 

    while (currentActivations.length > 0 && cascadeIterations < MAX_CASCADE_ITERATIONS) {
        cascadeIterations++;
        const nextWaveActivations: SpecialActivationDetail[] = [];
        
        currentActivations.forEach(sa => {
            const activationKey = `${posToString(sa.pos)}-${sa.type}`;
            if (alreadyActivatedThisTurn.has(activationKey)) return;

            anActionLedToAnimationOrGridChange = true; // Special is activating
            alreadyActivatedThisTurn.add(activationKey);
            finalPositionsToClear.add(posToString(sa.pos)); 
            
            sa.effectCells.forEach(effectPos => { 
                 finalPositionsToClear.add(posToString(effectPos));
                 const itemAtEffectPos = gridRef.current[effectPos.row]?.[effectPos.col];
                 if (itemAtEffectPos?.special !== undefined && !alreadyActivatedThisTurn.has(`${posToString(effectPos)}-${itemAtEffectPos.special}`)) {
                     const nextEffectCells = getSpecialEffectCells(effectPos, itemAtEffectPos.special);
                     const newActivation: SpecialActivationDetail = { pos: effectPos, type: itemAtEffectPos.special, effectCells: nextEffectCells, originalItem: {...itemAtEffectPos} };
                     if(!nextWaveActivations.some(nwa => nwa.pos.row === newActivation.pos.row && nwa.pos.col === newActivation.pos.col && nwa.type === newActivation.type)) {
                       nextWaveActivations.push(newActivation);
                       if(!allActivatedSpecials.some(aas => aas.pos.row === newActivation.pos.row && aas.pos.col === newActivation.pos.col && aas.type === newActivation.type)) {
                           allActivatedSpecials.push(newActivation);
                       }
                     }
                 }
            });
        });
        currentActivations = nextWaveActivations;
    }
    
    // Determine the next animation state based on what happened
    if (alreadyActivatedThisTurn.size > 0) { // If any special actually activated
        animationStateRef.current = { 
            type: 'special_activating', 
            // Pass only specials that were actually part of this activation turn to the animation
            activationDetails: allActivatedSpecials.filter(sa => alreadyActivatedThisTurn.has(`${posToString(sa.pos)}-${sa.type}`)), 
            startTime: Date.now(),
            processedActivations: new Set<string>(), // Will be populated by 'special_activating' animation phase
            allCellsToClearAfterSpecialActivation: finalPositionsToClear
        };
    } else if (finalPositionsToClear.size > 0) { // No specials activated, but items to clear (e.g. 3-match or special creation that clears others)
        anActionLedToAnimationOrGridChange = true; // Ensure this is true if items are being cleared
        scoreRef.current += finalPositionsToClear.size * POINTS_PER_ITEM;
        onScoreUpdate(scoreRef.current);
        animationStateRef.current = { type: 'matching', items: Array.from(finalPositionsToClear).map(stringToPos), startTime: Date.now() };
    } else if (anActionLedToAnimationOrGridChange) { 
        // This case means specials were created, but they didn't activate, and no other items were cleared.
        // The grid has changed. No new animation starts here from processGameActions.
        // The calling function (e.g., attempting_swap) will see true and might set state to idle, then handleNextStep.
    }
    // If anActionLedToAnimationOrGridChange is still false, it means no specials created, no activations, no clears.
    
    return anActionLedToAnimationOrGridChange;
  }, [onScoreUpdate, getSpecialEffectCells]);

  const handleNextStepInGameLogic = useCallback(() => {
    if (animationStateRef.current.type !== 'idle' || isShufflingBoardRef.current || isProcessingMoveRef.current) return;

    const analysisResult = analyzeGridState(gridRef.current);
    const actionsProcessed = processGameActions(analysisResult);

    if (!actionsProcessed) { 
        isProcessingMoveRef.current = false;
        if (!checkPossibleMoves()) {
            if (hasShuffledRecentlyRef.current) {
                onGameOver(); hasShuffledRecentlyRef.current = false;
            } else {
                isShufflingBoardRef.current = true; onShuffleBoardStateChange(true);
                hintToDisplayRef.current = null; if(hintTimerIdRef.current) clearTimeout(hintTimerIdRef.current);
                setTimeout(() => { if (shuffleBoard) shuffleBoard(); }, SHUFFLE_DELAY);
            }
        } else {
            hasShuffledRecentlyRef.current = false; lastInteractionTimeRef.current = Date.now();
            if(hintTimerIdRef.current) clearTimeout(hintTimerIdRef.current); hintToDisplayRef.current = null;
            hintTimerIdRef.current = setTimeout(() => { hintToDisplayRef.current = findHint(); }, HINT_DELAY);
        }
    }
  }, [analyzeGridState, processGameActions, checkPossibleMoves, onGameOver, findHint, onShuffleBoardStateChange]);

  shuffleBoard = useCallback(() => {
    isShufflingBoardRef.current = true; hasShuffledRecentlyRef.current = true;
    onShuffleBoardStateChange(false); 
    animationStateRef.current = {type: 'idle'}; isProcessingMoveRef.current = true; 
    
    const allItems: GridItem[] = [];
    gridRef.current.forEach(row => row.forEach(item => { if (item) allItems.push(item); }));
    for (let i = allItems.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [allItems[i], allItems[j]] = [allItems[j], allItems[i]]; }

    let currentItemIndex = 0;
    for (let r = 0; r < GRID_ROWS; r++) {
        for (let c = 0; c < GRID_COLS; c++) {
            gridRef.current[r][c] = currentItemIndex < allItems.length ? allItems[currentItemIndex++] : createRandomItem();
        }
    }
    
    let initialAnalysis: AnalysisResult; let attempts = 0; const MAX_SHUFFLE_FIX_ATTEMPTS = 10; 
    do {
        initialAnalysis = analyzeGridState(gridRef.current);
        if (initialAnalysis.positionsToClear.size > 0 || initialAnalysis.specialsToCreate.length > 0 || initialAnalysis.specialsToActivate.length > 0) {
            for (let r_ = 0; r_ < GRID_ROWS; r_++) for (let c_ = 0; c_ < GRID_COLS; c_++) gridRef.current[r_][c_] = createRandomItem();
        }
        attempts++;
    } while ((initialAnalysis.positionsToClear.size > 0 || initialAnalysis.specialsToCreate.length > 0 || initialAnalysis.specialsToActivate.length > 0) && attempts < MAX_SHUFFLE_FIX_ATTEMPTS);

    isProcessingMoveRef.current = false; isShufflingBoardRef.current = false;
    handleNextStepInGameLogic();
  }, [createRandomItem, analyzeGridState, handleNextStepInGameLogic, onShuffleBoardStateChange]);

  const advanceAnimations = useCallback(() => {
    const animState = animationStateRef.current;
    if (animState.type === 'idle') return true; 
    let animationCompletedThisFrame = false;

    if (animState.type === 'attempting_swap' && animState.attemptingSwapDetail) {
        const detail = animState.attemptingSwapDetail;
        const elapsed = Date.now() - animState.startTime!;
        const progress = Math.min(1, elapsed / ATTEMPTING_SWAP_ANIMATION_DURATION);

        detail.item1CurrentX = detail.pos1Start.col * CELL_SIZE + (detail.item1TargetX - detail.pos1Start.col * CELL_SIZE) * progress;
        detail.item1CurrentY = detail.pos1Start.row * CELL_SIZE + (detail.item1TargetY - detail.pos1Start.row * CELL_SIZE) * progress;
        detail.item2CurrentX = detail.pos2Start.col * CELL_SIZE + (detail.item2TargetX - detail.pos2Start.col * CELL_SIZE) * progress;
        detail.item2CurrentY = detail.pos2Start.row * CELL_SIZE + (detail.item2TargetY - detail.pos2Start.row * CELL_SIZE) * progress;

        if (progress >= 1) {
            const item1 = detail.item1; 
            const item2 = detail.item2; 

            if (item1 && item2) {
                gridRef.current[detail.pos1Start.row][detail.pos1Start.col] = item2;
                gridRef.current[detail.pos2Start.row][detail.pos2Start.col] = item1;

                const analysisResult = analyzeGridState(gridRef.current);
                const actionsProcessed = processGameActions(analysisResult);

                if (actionsProcessed) { 
                    if (detail.isDragSwap) {
                        let newPosOfDragged: Position | null = null;
                        for(let r=0; r<GRID_ROWS; r++) for(let c=0; c<GRID_COLS; c++) {
                            if(gridRef.current[r][c]?.id === detail.draggedItemOriginalId) {
                                newPosOfDragged = {row:r, col:c}; break;
                            }
                        }
                        if(newPosOfDragged) startDragCellRef.current = newPosOfDragged; else startDragCellRef.current = detail.pos2Start;
                        lastFailedSwapTargetRef.current = null;
                    }
                     if(animationStateRef.current.type === 'attempting_swap') { 
                         animationStateRef.current = {type: 'idle'};
                         animationCompletedThisFrame = true; 
                     }
                } else { 
                    gridRef.current[detail.pos1Start.row][detail.pos1Start.col] = item1;
                    gridRef.current[detail.pos2Start.row][detail.pos2Start.col] = item2;
                    
                    animationStateRef.current = {
                        type: 'invalid_swap',
                        animatedSwapItems: [
                          { item: item1, startX: detail.item1TargetX, startY: detail.item1TargetY, currentX: detail.item1TargetX, currentY: detail.item1TargetY, endX: detail.pos1Start.col * CELL_SIZE, endY: detail.pos1Start.row * CELL_SIZE, originalGridPos: detail.pos1Start },
                          { item: item2, startX: detail.item2TargetX, startY: detail.item2TargetY, currentX: detail.item2TargetX, currentY: detail.item2TargetY, endX: detail.pos2Start.col * CELL_SIZE, endY: detail.pos2Start.row * CELL_SIZE, originalGridPos: detail.pos2Start }
                        ],
                        startTime: Date.now(),
                    };
                    if (detail.isDragSwap) {
                        lastFailedSwapTargetRef.current = detail.pos2Start; 
                    }
                }
            } else { 
                animationStateRef.current = { type: 'idle' }; animationCompletedThisFrame = true;
            }
        }
    } else if (animState.type === 'special_activating') {
        const elapsed = Date.now() - animState.startTime!;
        const progress = Math.min(1, elapsed / SPECIAL_ACTIVATION_ANIMATION_DURATION);
        
        let allEffectsVisuallyDone = true;
        animState.activationDetails?.forEach(detail => {
            const key = `${posToString(detail.pos)}-${detail.type}`;
            if (!animState.processedActivations?.has(key)) {
                allEffectsVisuallyDone = false;
                if (progress >=1) animState.processedActivations?.add(key);
            }
        });

        if (allEffectsVisuallyDone || progress >=1) { 
            const cellsToPassToMatching = animState.allCellsToClearAfterSpecialActivation || new Set<string>();
            if (cellsToPassToMatching.size > 0) {
                 scoreRef.current += cellsToPassToMatching.size * POINTS_PER_ITEM; 
                 onScoreUpdate(scoreRef.current);
                 animationStateRef.current = { type: 'matching', items: Array.from(cellsToPassToMatching).map(stringToPos), startTime: Date.now() };
            } else {
                 animationStateRef.current = { type: 'idle' }; animationCompletedThisFrame = true;
            }
        }
    } else if (animState.type === 'matching') {
        const elapsed = Date.now() - animState.startTime!;
        const progress = Math.min(1, elapsed / MATCH_ANIMATION_DURATION);
        if (progress >= 1) {
            removeMatchedItemsFromGrid(animState.items as Position[]);
            const { newFallingItems } = applyGravityToGrid();
            if (newFallingItems.length > 0) animationStateRef.current = { type: 'falling', items: newFallingItems, startTime: Date.now() };
            else {
                const { newRefillingItems } = refillGridWithNewItems();
                 if (newRefillingItems.length > 0) animationStateRef.current = { type: 'refilling', items: newRefillingItems, startTime: Date.now() };
                else { animationStateRef.current = { type: 'idle' }; animationCompletedThisFrame = true; }
            }
        }
    } else if (animState.type === 'falling' || animState.type === 'refilling') {
        let allLanded = true;
        const speed = animState.type === 'falling' ? FALL_ANIMATION_SPEED : REFILL_ANIMATION_SPEED;
        (animState.items as AnimatedItem[]).forEach(item => {
            if (!item.landed) {
                item.currentY += speed;
                if (item.currentY >= item.toY) { item.currentY = item.toY; item.landed = true; } 
                else allLanded = false;
            }
        });
        if (allLanded) {
            if (animState.type === 'falling') {
                const { newRefillingItems } = refillGridWithNewItems();
                if (newRefillingItems.length > 0) animationStateRef.current = { type: 'refilling', items: newRefillingItems, startTime: Date.now() };
                else { animationStateRef.current = { type: 'idle' }; animationCompletedThisFrame = true; }
            } else { animationStateRef.current = { type: 'idle' }; animationCompletedThisFrame = true; }
        }
    } else if (animState.type === 'invalid_swap') {
        const elapsed = Date.now() - animState.startTime!;
        const progress = Math.min(1, elapsed / INVALID_SWAP_ANIMATION_DURATION);
        let allMovedBack = true;
        animState.animatedSwapItems?.forEach(item => {
            if (item.currentX !== item.endX || item.currentY !== item.endY) {
                allMovedBack = false;
                item.currentX = item.startX + (item.endX - item.startX) * progress;
                item.currentY = item.startY + (item.endY - item.startY) * progress;
                if (progress >= 1) {
                    item.currentX = item.endX;
                    item.currentY = item.endY;
                }
            }
        });
        if (allMovedBack || progress >= 1) {
            animationStateRef.current = { type: 'idle' };
            animationCompletedThisFrame = true;
        }
    }

    if (animationCompletedThisFrame) {
        isProcessingMoveRef.current = false;
        handleNextStepInGameLogic();
    }
    return animationStateRef.current.type === 'idle';
  }, [removeMatchedItemsFromGrid, applyGravityToGrid, refillGridWithNewItems, handleNextStepInGameLogic, onScoreUpdate, analyzeGridState, processGameActions]);

  const initializeGridAndGame = useCallback(() => {
    isShufflingBoardRef.current = false; hasShuffledRecentlyRef.current = false; onShuffleBoardStateChange(false);
    isProcessingMoveRef.current = true; 
    let newGrid: (GridItem | null)[][] = [];
    for (let r = 0; r < GRID_ROWS; r++) {
      newGrid[r] = [];
      for (let c = 0; c < GRID_COLS; c++) {
        let excludedTypes: ShapeType[] = [];
        if (c >= 2 && newGrid[r][c-1]?.type === newGrid[r][c-2]?.type) if(newGrid[r][c-1]) excludedTypes.push(newGrid[r][c-1]!.type);
        if (r >= 2 && newGrid[r-1][c]?.type === newGrid[r-2][c]?.type) if(newGrid[r-1][c]) excludedTypes.push(newGrid[r-1][c]!.type);
        newGrid[r][c] = createRandomItem(excludedTypes);
      }
    }
    gridRef.current = newGrid;
    
    let initialAnalysis: AnalysisResult; let attempts = 0; const MAX_INIT_FIX_ATTEMPTS = 10;
    do {
        initialAnalysis = analyzeGridState(gridRef.current);
        if (initialAnalysis.positionsToClear.size > 0 || initialAnalysis.specialsToCreate.length > 0 || initialAnalysis.specialsToActivate.length > 0) {
            for (let r_ = 0; r_ < GRID_ROWS; r_++) for (let c_ = 0; c_ < GRID_COLS; c_++) gridRef.current[r_][c_] = createRandomItem();
        }
        attempts++;
    } while ((initialAnalysis.positionsToClear.size > 0 || initialAnalysis.specialsToCreate.length > 0 || initialAnalysis.specialsToActivate.length > 0) && attempts < MAX_INIT_FIX_ATTEMPTS);
    
    scoreRef.current = 0; onScoreUpdate(0);
    animationStateRef.current = { type: 'idle' }; 
    isProcessingMoveRef.current = false; 
    handleNextStepInGameLogic();
  }, [createRandomItem, analyzeGridState, onScoreUpdate, handleNextStepInGameLogic, onShuffleBoardStateChange]);

  const drawGame = useCallback(() => {
    if (!ctxRef.current || !canvasRef.current) return;
    const ctx = ctxRef.current;
    ctx.clearRect(0, 0, width, height);

    const isIdleAndNotProcessing = advanceAnimations(); 
    const animState = animationStateRef.current;

    for (let r = 0; r < GRID_ROWS; r++) {
      for (let c = 0; c < GRID_COLS; c++) {
        const item = gridRef.current[r]?.[c];
        if (item) {
          let hideItem = false;
          if (animState.type === 'attempting_swap' && animState.attemptingSwapDetail) {
            const d = animState.attemptingSwapDetail;
            if ((d.pos1Start.row === r && d.pos1Start.col === c) || (d.pos2Start.row === r && d.pos2Start.col === c)) {
              hideItem = true; 
            }
          } else if (animState.type === 'matching' && (animState.items as Position[]).some(p => p.row === r && p.col === c)) {
            hideItem = true; 
          } else if ((animState.type === 'falling' || animState.type === 'refilling') && (animState.items as AnimatedItem[]).some(ai => ai.item.id === item.id)) {
            hideItem = true;
          } else if (animState.type === 'special_activating' && animState.activationDetails?.some(ad => ad.effectCells.some(ec => ec.row ===r && ec.col ===c) || (ad.pos.row === r && ad.pos.col ===c) )) {
            if(animState.activationDetails?.some(ad => ad.pos.row ===r && ad.pos.col ===c && !animState.processedActivations?.has(`${posToString(ad.pos)}-${ad.type}`))) {
            } else { 
                hideItem = true;
            }
          } else if (animState.type === 'invalid_swap' && animState.animatedSwapItems?.some(asi => asi.originalGridPos.row ===r && asi.originalGridPos.col ===c )) {
             hideItem = true;
          }
          if (isDraggingRef.current && startDragCellRef.current?.row === r && startDragCellRef.current?.col === c && isIdleAndNotProcessing) {
             hideItem = true;
          }
          
          if (!hideItem) {
             drawShape(ctx, item, c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE);
          }
        }
      }
    }
    
    if (animState.type === 'attempting_swap' && animState.attemptingSwapDetail) {
        const d = animState.attemptingSwapDetail;
        drawShape(ctx, d.item1, d.item1CurrentX, d.item1CurrentY, CELL_SIZE);
        drawShape(ctx, d.item2, d.item2CurrentX, d.item2CurrentY, CELL_SIZE);
    } else if (animState.type === 'special_activating') {
        const elapsed = Date.now() - animState.startTime!;
        const progress = Math.min(1, elapsed / SPECIAL_ACTIVATION_ANIMATION_DURATION);
        animState.activationDetails?.forEach(detail => {
            const key = `${posToString(detail.pos)}-${detail.type}`;
            if (animState.processedActivations?.has(key)) return; 

            ctx.save();
            const centerX = detail.pos.col * CELL_SIZE + CELL_SIZE / 2;
            const centerY = detail.pos.row * CELL_SIZE + CELL_SIZE / 2;
            
            const activatingItemVisual = gridRef.current[detail.pos.row]?.[detail.pos.col] || detail.originalItem;

            switch(detail.type) {
                case SpecialItemType.LINE_H:
                case SpecialItemType.LINE_V:
                case SpecialItemType.CROSS_CLEAR: 
                    ctx.fillStyle = activatingItemVisual.color;
                    ctx.globalAlpha = 0.7 * (1 - progress); 
                    if (detail.type === SpecialItemType.LINE_H || detail.type === SpecialItemType.CROSS_CLEAR) {
                        ctx.fillRect(0, detail.pos.row * CELL_SIZE + CELL_SIZE * 0.25, width * progress, CELL_SIZE * 0.5);
                    }
                    if (detail.type === SpecialItemType.LINE_V || detail.type === SpecialItemType.CROSS_CLEAR) {
                         ctx.fillRect(detail.pos.col * CELL_SIZE + CELL_SIZE * 0.25, 0, CELL_SIZE * 0.5, height * progress);
                    }
                    break;
                case SpecialItemType.BOMB:
                    ctx.fillStyle = activatingItemVisual.color;
                    ctx.globalAlpha = 0.5 * (1 - progress);
                    ctx.beginPath();
                    ctx.arc(centerX, centerY, CELL_SIZE * (BOMB_EFFECT_RADIUS + 0.5) * progress, 0, Math.PI * 2);
                    ctx.fill();
                    break;
                case SpecialItemType.SCREEN_CLEAR:
                    ctx.fillStyle = activatingItemVisual.color;
                    ctx.globalAlpha = 0.4 * (1-progress);
                    ctx.beginPath();
                    ctx.arc(width/2, height/2, Math.max(width,height) * progress, 0, Math.PI * 2);
                    ctx.fill();
                    break;
            }
             drawShape(ctx, activatingItemVisual, detail.pos.col * CELL_SIZE, detail.pos.row * CELL_SIZE, CELL_SIZE, 1-progress, 1+ (progress*0.2)); 

            ctx.restore();
        });

    } else if (animState.type === 'matching') {
        const elapsed = Date.now() - animState.startTime!; const progress = Math.min(1, elapsed / MATCH_ANIMATION_DURATION);
        const scale = 1 - progress; const alpha = 1 - progress;
        (animState.items as Position[]).forEach(pos => {
            const itemToDraw = gridRef.current[pos.row]?.[pos.col]; 
            if (itemToDraw) drawShape(ctx, itemToDraw, pos.col * CELL_SIZE, pos.row * CELL_SIZE, CELL_SIZE, alpha, scale);
        });
    } else if (animState.type === 'falling' || animState.type === 'refilling') {
        (animState.items as AnimatedItem[]).forEach(animItem => {
            if(animItem.item) drawShape(ctx, animItem.item, animItem.col * CELL_SIZE, animItem.currentY, CELL_SIZE);
        });
    } else if (animState.type === 'invalid_swap') {
        animState.animatedSwapItems?.forEach(asi => {
            drawShape(ctx, asi.item, asi.currentX, asi.currentY, CELL_SIZE);
        });
    }

    if (isDraggingRef.current && startDragCellRef.current && draggedItemMousePosRef.current && isIdleAndNotProcessing) {
      const draggedItem = gridRef.current[startDragCellRef.current.row]?.[startDragCellRef.current.col];
      if (draggedItem) {
        drawShape(
            ctx, 
            draggedItem, 
            draggedItemMousePosRef.current.x - CELL_SIZE / 2, 
            draggedItemMousePosRef.current.y - CELL_SIZE / 2,
            CELL_SIZE, 
            DRAG_ITEM_ALPHA, 
            DRAG_ITEM_SCALE
        );
      }
    }
    
    if (hintToDisplayRef.current && animState.type === 'idle' && !isProcessingMoveRef.current && !isShufflingBoardRef.current) {
        const pulseFactor = Math.abs(Math.sin(Date.now() / HINT_PULSE_SPEED));
        ctx.save();
        ctx.lineWidth = 3 + pulseFactor * 2; ctx.strokeStyle = `rgba(255, 255, 0, ${0.5 + pulseFactor * 0.5})`;
        if (Array.isArray(hintToDisplayRef.current)) hintToDisplayRef.current.forEach(p=>ctx.strokeRect(p.col*CELL_SIZE+ctx.lineWidth/2,p.row*CELL_SIZE+ctx.lineWidth/2,CELL_SIZE-ctx.lineWidth,CELL_SIZE-ctx.lineWidth));
        else { const p=hintToDisplayRef.current as Position; ctx.strokeRect(p.col*CELL_SIZE+ctx.lineWidth/2,p.row*CELL_SIZE+ctx.lineWidth/2,CELL_SIZE-ctx.lineWidth,CELL_SIZE-ctx.lineWidth);}
        ctx.restore();
    }
    
    animationFrameIdRef.current = requestAnimationFrame(drawGame);
  }, [width, height, drawShape, advanceAnimations]);
  
  const triggerPlayerAction = useCallback(() => {
    lastInteractionTimeRef.current = Date.now(); if(hintTimerIdRef.current) clearTimeout(hintTimerIdRef.current); hintToDisplayRef.current = null;
  }, []);

  const activateSpecialItemOnClick = useCallback((row: number, col: number) => {
    if (isProcessingMoveRef.current || animationStateRef.current.type !== 'idle' || isShufflingBoardRef.current) return;
    const item = gridRef.current[row]?.[col];
    if (!item || item.special === undefined) return;

    triggerPlayerAction();
    isProcessingMoveRef.current = true;
    
    const clickAnalysis: AnalysisResult = { positionsToClear: new Set<string>(), specialsToCreate: [], specialsToActivate: [] };
    const actionsProcessed = processGameActions(clickAnalysis, {row, col});
    
    if (!actionsProcessed) {
         isProcessingMoveRef.current = false; 
    }
  }, [processGameActions, triggerPlayerAction]);

  const getCellFromMouseEvent = (event: MouseEvent): Position & {x: number, y: number} => {
    if (!canvasRef.current) return { row: -1, col: -1, x:0, y:0 };
    const rect = canvasRef.current.getBoundingClientRect();
    const x = event.clientX - rect.left; const y = event.clientY - rect.top;
    const col = Math.floor(x / CELL_SIZE); const row = Math.floor(y / CELL_SIZE);
    return { row, col, x, y };
  };

  const handleMouseDown = useCallback((event: MouseEvent) => {
    if (isProcessingMoveRef.current || animationStateRef.current.type !== 'idle' || isShufflingBoardRef.current) return;
    const { row, col, x, y } = getCellFromMouseEvent(event);
    if (row >= 0 && row < GRID_ROWS && col >= 0 && col < GRID_COLS && gridRef.current[row]?.[col]) {
      startDragCellRef.current = { row, col }; 
      clickStartPosRef.current = {row, col}; 
      draggedItemMousePosRef.current = { x , y };
      isDraggingRef.current = true; 
      potentialClickRef.current = true; 
      lastFailedSwapTargetRef.current = null; 
    }
  }, []);

  const handleMouseMove = useCallback((event: MouseEvent) => {
    if (!isDraggingRef.current || !startDragCellRef.current || isShufflingBoardRef.current) return;
    
    const { row: hoverRow, col: hoverCol, x, y } = getCellFromMouseEvent(event);
    draggedItemMousePosRef.current = { x, y };

    if (potentialClickRef.current && clickStartPosRef.current &&
        (hoverRow !== clickStartPosRef.current.row || hoverCol !== clickStartPosRef.current.col)) {
        potentialClickRef.current = false;
        triggerPlayerAction(); 
    }
    
    if (isProcessingMoveRef.current || animationStateRef.current.type !== 'idle') {
        return;
    }

    const startPos = startDragCellRef.current;
    if (hoverRow >= 0 && hoverRow < GRID_ROWS && hoverCol >= 0 && hoverCol < GRID_COLS &&
        (hoverRow !== startPos.row || hoverCol !== startPos.col)) { 
        
        const dr = Math.abs(hoverRow - startPos.row);
        const dc = Math.abs(hoverCol - startPos.col);

        if ((dr === 1 && dc === 0) || (dr === 0 && dc === 1)) { 
            if (!lastFailedSwapTargetRef.current || lastFailedSwapTargetRef.current.row !== hoverRow || lastFailedSwapTargetRef.current.col !== hoverCol) {
                potentialClickRef.current = false; 

                const item1 = gridRef.current[startPos.row]?.[startPos.col];
                const item2 = gridRef.current[hoverRow]?.[hoverCol];

                if (item1 && item2) {
                    isProcessingMoveRef.current = true; 
                    triggerPlayerAction();

                    animationStateRef.current = {
                        type: 'attempting_swap',
                        startTime: Date.now(),
                        attemptingSwapDetail: {
                            item1: {...item1}, item2: {...item2},
                            pos1Start: startPos, pos2Start: {row: hoverRow, col: hoverCol},
                            item1TargetX: hoverCol * CELL_SIZE, item1TargetY: hoverRow * CELL_SIZE,
                            item2TargetX: startPos.col * CELL_SIZE, item2TargetY: startPos.row * CELL_SIZE,
                            item1CurrentX: startPos.col * CELL_SIZE, item1CurrentY: startPos.row * CELL_SIZE,
                            item2CurrentX: hoverCol * CELL_SIZE, item2CurrentY: hoverRow * CELL_SIZE,
                            isDragSwap: true,
                            draggedItemOriginalId: item1.id,
                        }
                    };
                }
            }
        } else { 
            lastFailedSwapTargetRef.current = null;
        }
    } else { 
        lastFailedSwapTargetRef.current = null;
    }
  }, [triggerPlayerAction]);

  const handleMouseUp = useCallback((event: MouseEvent) => {
    if (potentialClickRef.current && clickStartPosRef.current && !isShufflingBoardRef.current && animationStateRef.current.type === 'idle' && !isProcessingMoveRef.current) {
        const { row: clickRow, col: clickCol } = getCellFromMouseEvent(event);
        if (clickStartPosRef.current.row === clickRow && clickStartPosRef.current.col === clickCol) {
            const item = gridRef.current[clickRow]?.[clickCol];
            if (item?.special !== undefined) {
                activateSpecialItemOnClick(clickRow, clickCol);
            }
        }
    }
    
    isDraggingRef.current = false; 
    potentialClickRef.current = false; 
    clickStartPosRef.current = null;
    
    if (!isProcessingMoveRef.current && animationStateRef.current.type === 'idle' && !isShufflingBoardRef.current) {
        handleNextStepInGameLogic();
    }
  }, [activateSpecialItemOnClick, handleNextStepInGameLogic]);


  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    ctxRef.current = canvas.getContext('2d');
    initializeGridAndGame();
    
    canvas.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove); 
    window.addEventListener('mouseup', handleMouseUp); 
    
    animationFrameIdRef.current = requestAnimationFrame(drawGame);

    return () => {
      if (animationFrameIdRef.current) cancelAnimationFrame(animationFrameIdRef.current);
      if (hintTimerIdRef.current) clearTimeout(hintTimerIdRef.current);
      canvas.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initializeGridAndGame]); 

  return (
    <canvas 
      ref={canvasRef} 
      width={width} 
      height={height} 
      className="border-4 border-slate-600 rounded-xl shadow-2xl bg-slate-700/50 cursor-grab active:cursor-grabbing"
      aria-label="Shape Matcher Game Board"
      role="application"
      onContextMenu={(e) => e.preventDefault()} 
    />
  );
};

export default GameCanvas;
