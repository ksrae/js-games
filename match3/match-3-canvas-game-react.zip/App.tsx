import React, { useState, useCallback } from 'react';
import GameCanvas from './components/GameCanvas';
import { GRID_COLS, GRID_ROWS, CELL_SIZE } from './constants';

const App: React.FC = () => {
  const [gameKey, setGameKey] = useState(0);
  const [score, setScore] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);
  const [showShuffleMessage, setShowShuffleMessage] = useState(false);

  const handleRestartGame = useCallback(() => {
    setGameKey(prevKey => prevKey + 1);
    setScore(0);
    setIsGameOver(false);
    setShowShuffleMessage(false);
  }, []);

  const handleGameOver = useCallback(() => {
    setIsGameOver(true);
    setShowShuffleMessage(false);
  }, []);

  const handleShowShuffleMessage = useCallback((show: boolean) => {
    setShowShuffleMessage(show);
  }, []);

  return (
    <div className="flex flex-col items-center p-4">
      <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 mb-2">Shape Matcher</h1>
      <p className="text-gray-300 mb-6 text-lg">Match items to score points! Create special items for big clears.</p>
      
      <div className="mb-4 p-4 bg-slate-700 rounded-lg shadow-md w-full max-w-md flex justify-between items-center">
        <div className="text-2xl font-semibold text-white">
          Score: <span className="text-yellow-400">{score}</span>
        </div>
        <button 
          onClick={handleRestartGame} 
          className="px-6 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-semibold rounded-lg hover:from-blue-600 hover:to-indigo-700 transition-all duration-150 shadow-md focus:outline-none focus:ring-2 focus:ring-indigo-400"
          aria-label="Restart Game"
        >
          Restart
        </button>
      </div>

      {isGameOver && (
        <div className="mb-4 p-3 bg-red-600 text-white text-xl font-semibold text-center rounded-lg shadow-md w-full max-w-md" role="alert">
          Game Over! Press Restart.
        </div>
      )}
      {showShuffleMessage && !isGameOver && (
        <div className="mb-4 p-3 bg-yellow-500 text-black text-lg font-semibold text-center rounded-lg shadow-md w-full max-w-md" role="status">
          No more moves! Shuffling board...
        </div>
      )}
      
      <GameCanvas 
        key={gameKey} 
        width={GRID_COLS * CELL_SIZE} 
        height={GRID_ROWS * CELL_SIZE}
        onScoreUpdate={setScore}
        onGameOver={handleGameOver}
        onShuffleBoardStateChange={handleShowShuffleMessage}
      />
      <footer className="mt-8 text-center text-gray-400">
        <p>Built with React, TypeScript, and Tailwind CSS.</p>
        <p>Tip: 4 in a row makes a Line Clear. A 2x2 square makes a Bomb! 5 in a row clears the screen!</p>
      </footer>
    </div>
  );
};

export default App;