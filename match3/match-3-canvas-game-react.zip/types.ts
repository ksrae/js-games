export enum ShapeType {
  CIRCLE,
  SQUARE,
  TRIANGLE,
  DIAMOND,
  HEXAGON,
  STAR,
}

export enum SpecialItemType {
  LINE_H, // Clears horizontally
  LINE_V, // Clears vertically
  BOMB,   // Clears a 3x3 area
  SCREEN_CLEAR, // Clears all items on the board
  CROSS_CLEAR,  // Clears the entire row and column
}

export interface GridItem {
  type: ShapeType;
  color: string;
  id: string; 
  special?: SpecialItemType; // For special items like line clears, bombs
}

export interface Position {
  row: number;
  col: number;
}